// Buffer cache.
//
// The buffer cache is a linked list of buf structures holding
// cached copies of disk block contents.  Caching disk blocks
// in memory reduces the number of disk reads and also provides
// a synchronization point for disk blocks used by multiple processes.
//
// Interface:
// * To get a buffer for a particular disk block, call bread.
// * After changing buffer data, call bwrite to write it to disk.
// * When done with the buffer, call brelse.
// * Do not use the buffer after calling brelse.
// * Only one process at a time can use a buffer,
//     so do not keep them longer than necessary.


#include "types.h"
#include "param.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "riscv.h"
#include "defs.h"
#include "fs.h"
#include "buf.h"

#define NBUCKET 13

struct {
  struct spinlock lock; // serializes cache misses and buffer reassignment
  struct spinlock bucket_lock[NBUCKET];
  struct buf buf[NBUF];
  struct buf *bucket[NBUCKET];
  struct buf *unused;
} bcache;

static uint
hash(uint dev, uint blockno)
{
  return (blockno * 31 + dev) % NBUCKET;
}

static struct buf*
findbuf(uint dev, uint blockno, uint bucket)
{
  struct buf *b;

  for(b = bcache.bucket[bucket]; b; b = b->next){
    if(b->dev == dev && b->blockno == blockno)
      return b;
  }
  return 0;
}

static void
removebuf(uint bucket, struct buf *target)
{
  struct buf **link;

  for(link = &bcache.bucket[bucket]; *link; link = &(*link)->next){
    if(*link == target){
      *link = target->next;
      target->next = 0;
      return;
    }
  }
  panic("removebuf");
}

void
binit(void)
{
  struct buf *b;

  initlock(&bcache.lock, "bcache");
  for(int i = 0; i < NBUCKET; i++)
    initlock(&bcache.bucket_lock[i], "bcache.bucket");
  bcache.unused = 0;
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    initsleeplock(&b->lock, "buffer");
    b->refcnt = 0;
    b->next = bcache.unused;
    bcache.unused = b;
  }
}

// Look through buffer cache for block on device dev.
// If not found, allocate a buffer.
// In either case, return locked buffer.
static struct buf*
bget(uint dev, uint blockno)
{
  struct buf *b;
  uint target = hash(dev, blockno);

  acquire(&bcache.bucket_lock[target]);
  b = findbuf(dev, blockno, target);
  if(b){
    b->refcnt++;
    release(&bcache.bucket_lock[target]);
    acquiresleep(&b->lock);
    return b;
  }
  release(&bcache.bucket_lock[target]);

  // Serialize misses so a block can never be installed twice.
  acquire(&bcache.lock);
  acquire(&bcache.bucket_lock[target]);
  b = findbuf(dev, blockno, target);
  if(b){
    b->refcnt++;
    release(&bcache.bucket_lock[target]);
    release(&bcache.lock);
    acquiresleep(&b->lock);
    return b;
  }
  release(&bcache.bucket_lock[target]);

  if(bcache.unused){
    b = bcache.unused;
    bcache.unused = b->next;
    b->next = 0;
  } else {
    b = 0;
    for(uint i = 0; i < NBUCKET && b == 0; i++){
      acquire(&bcache.bucket_lock[i]);
      for(struct buf *candidate = bcache.bucket[i]; candidate; candidate = candidate->next){
        if(candidate->refcnt == 0){
          b = candidate;
          removebuf(i, b);
          break;
        }
      }
      release(&bcache.bucket_lock[i]);
    }
  }

  if(b == 0){
    release(&bcache.lock);
    panic("bget: no buffers");
  }
  b->dev = dev;
  b->blockno = blockno;
  b->valid = 0;
  b->refcnt = 1;
  acquire(&bcache.bucket_lock[target]);
  b->next = bcache.bucket[target];
  bcache.bucket[target] = b;
  release(&bcache.bucket_lock[target]);
  release(&bcache.lock);
  acquiresleep(&b->lock);
  return b;
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    virtio_disk_rw(b->dev, b, 0);
    b->valid = 1;
  }
  return b;
}

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
  if(!holdingsleep(&b->lock))
    panic("bwrite");
  virtio_disk_rw(b->dev, b, 1);
}

// Release a locked buffer.
// Move to the head of the MRU list.
void
brelse(struct buf *b)
{
  uint bucket;

  if(!holdingsleep(&b->lock))
    panic("brelse");

  releasesleep(&b->lock);
  bucket = hash(b->dev, b->blockno);
  acquire(&bcache.bucket_lock[bucket]);
  if(b->refcnt < 1)
    panic("brelse refcnt");
  b->refcnt--;
  release(&bcache.bucket_lock[bucket]);
}

void
bpin(struct buf *b) {
  acquire(&bcache.bucket_lock[hash(b->dev, b->blockno)]);
  b->refcnt++;
  release(&bcache.bucket_lock[hash(b->dev, b->blockno)]);
}

void
bunpin(struct buf *b) {
  acquire(&bcache.bucket_lock[hash(b->dev, b->blockno)]);
  if(b->refcnt < 1)
    panic("bunpin refcnt");
  b->refcnt--;
  release(&bcache.bucket_lock[hash(b->dev, b->blockno)]);
}

