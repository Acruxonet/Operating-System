#include "kernel/types.h"
#include "kernel/fcntl.h"
#include "user/user.h"

#define LINE_SIZE 256
#define MAX_COMMANDS 16
#define MAX_ARGS 16
#define MAX_TOKENS 64

struct command {
  char *argv[MAX_ARGS];
  char *input;
  char *output;
};

static char line[LINE_SIZE];
static struct command commands[MAX_COMMANDS];
static int pids[MAX_COMMANDS];

static int
isspace(char c)
{
  return c == ' ' || c == '\t' || c == '\n' || c == '\r';
}

static int
isoperator(char c)
{
  return c == '<' || c == '>' || c == '|';
}

static int
parse(char *s, struct command *cmds)
{
  char *tokens[MAX_TOKENS];
  int ntokens = 0;
  int ncmds = 1;
  int nargs[MAX_COMMANDS];
  char *p = s;

  memset(cmds, 0, sizeof(struct command) * MAX_COMMANDS);
  memset(nargs, 0, sizeof(nargs));
  while (*p) {
    while (isspace(*p))
      p++;
    if (*p == 0)
      break;
    if (ntokens == MAX_TOKENS)
      return -1;
    if (isoperator(*p)) {
      char op = *p++;
      tokens[ntokens++] = op == '<' ? "<" : op == '>' ? ">" : "|";
      continue;
    }
    tokens[ntokens++] = p;
    while (*p && !isspace(*p) && !isoperator(*p))
      p++;
    if (isoperator(*p)) {
      char op = *p++;
      if (ntokens == MAX_TOKENS)
        return -1;
      p[-1] = 0;
      tokens[ntokens++] = op == '<' ? "<" : op == '>' ? ">" : "|";
    } else if (*p) {
      *p++ = 0;
    }
  }
  if (ntokens == 0)
    return 0;

  for (int i = 0; i < ntokens; i++) {
    char *t = tokens[i];
    if (t[0] == '|' && t[1] == 0) {
      if (ncmds == MAX_COMMANDS || nargs[ncmds - 1] == 0)
        return -1;
      ncmds++;
    } else if ((t[0] == '<' || t[0] == '>') && t[1] == 0) {
      if (i + 1 == ntokens || tokens[i + 1][0] == '<' ||
          tokens[i + 1][0] == '>' || tokens[i + 1][0] == '|')
        return -1;
      if (t[0] == '<')
        cmds[ncmds - 1].input = tokens[++i];
      else
        cmds[ncmds - 1].output = tokens[++i];
    } else {
      if (nargs[ncmds - 1] >= MAX_ARGS - 1)
        return -1;
      cmds[ncmds - 1].argv[nargs[ncmds - 1]++] = t;
    }
  }
  if (nargs[ncmds - 1] == 0)
    return -1;
  return ncmds;
}

static void
childexec(struct command *cmd, int input, int hasnext, int pipefd[2])
{
  int fd;

  if (input >= 0) {
    close(0);
    if (dup(input) != 0) {
      fprintf(2, "nsh: dup input failed\n");
      exit(1);
    }
  }
  if (hasnext) {
    close(1);
    if (dup(pipefd[1]) != 1) {
      fprintf(2, "nsh: dup output failed\n");
      exit(1);
    }
  }
  if (input >= 0)
    close(input);
  if (hasnext) {
    close(pipefd[0]);
    close(pipefd[1]);
  }

  if (cmd->input) {
    close(0);
    fd = open(cmd->input, O_RDONLY);
    if (fd != 0) {
      fprintf(2, "nsh: cannot open %s\n", cmd->input);
      exit(1);
    }
  }
  if (cmd->output) {
    close(1);
    fd = open(cmd->output, O_CREATE | O_WRONLY);
    if (fd != 1) {
      fprintf(2, "nsh: cannot open %s\n", cmd->output);
      exit(1);
    }
  }

  exec(cmd->argv[0], cmd->argv);
  fprintf(2, "nsh: exec %s failed\n", cmd->argv[0]);
  exit(1);
}

static void
runline(char *s)
{
  int ncmds, prev, pipefd[2], pid;
  int npids = 0;

  ncmds = parse(s, commands);
  if (ncmds < 0) {
    fprintf(2, "nsh: invalid command\n");
    return;
  }
  if (ncmds == 0)
    return;

  prev = -1;
  for (int i = 0; i < ncmds; i++) {
    int hasnext = i + 1 < ncmds;
    if (hasnext && pipe(pipefd) < 0) {
      fprintf(2, "nsh: pipe failed\n");
      if (prev >= 0)
        close(prev);
      break;
    }
    pid = fork();
    if (pid < 0) {
      fprintf(2, "nsh: fork failed\n");
      if (hasnext) {
        close(pipefd[0]);
        close(pipefd[1]);
      }
      if (prev >= 0)
        close(prev);
      break;
    }
    if (pid == 0)
      childexec(&commands[i], prev, hasnext, pipefd);

    pids[npids++] = pid;
    if (prev >= 0)
      close(prev);
    if (hasnext) {
      close(pipefd[1]);
      prev = pipefd[0];
    } else {
      prev = -1;
    }
  }
  if (prev >= 0)
    close(prev);
  while (npids-- > 0)
    wait(0);
}

int
main(void)
{
  for (;;) {
    fprintf(2, "@ ");
    gets(line, sizeof(line));
    if (line[0] == 0)
      exit(0);
    runline(line);
  }
}
